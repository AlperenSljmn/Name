import random
import string
from django.shortcuts import render
from .models import TargetName

def generate_target_name():
    prefix = ''.join(random.choices(string.ascii_uppercase, k=4))
    number = random.randint(100, 999)
    return f"{prefix}-{number}"

def index(request):
    message = None
    current_target = TargetName.objects.order_by('-created_at').first()

    if request.method == 'POST':
        if 'generate' in request.POST:
            value = generate_target_name()
            current_target = TargetName.objects.create(value=value)
            message = 'New target name generated.'

        elif 'verify' in request.POST:
            candidate = request.POST.get('candidate')
            if current_target and candidate == current_target.value:
                message = 'MATCH'
            else:
                message = 'NO MATCH'

    return render(request, 'index.html', {
        'target': current_target,
        'message': message
    })
